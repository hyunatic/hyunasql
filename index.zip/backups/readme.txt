Database backups are stored here.
To change the backup folder setting, please edit 'config/backups.php' file.